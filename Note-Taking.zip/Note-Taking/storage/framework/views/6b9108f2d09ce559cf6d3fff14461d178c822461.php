<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card">
               

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <nav class="navbar navbar-expand-lg navbar-light bg-success">
                        <a class="navbar-brand" href="#">
                        <p style="font-size: 30px;">
                            THE NOTES TAKER
                        </p>
  
                        </a>
                    </nav>
                    <form action="<?php echo e(route('Note.store')); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                    <div class="container my-3">
                    <h1>Take your Notes here</h1>
                    <div class="card">

                        <div class="card-body">
                            <h5 class="card-title">
                                Add a Note
                            
                            </h5>
                            <div class="form-group">
                                <textarea class="form-control" 
                                    id="addTxt"  name="addTxt" rows="3" require>
                                </textarea>
                            </div>
                            <button class="btn btn-primary" 
                                id="addBtn" type="submit" style=
                                "background-color:green">
                                Add Note
                            </button>
                        </div>
                        
                    </div>
                    <hr>
                    </div>  
                    
                </div>
                </form>    
            </div>
        </div>
        
        <div class="col-md-7">
        <div class="table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                           <th>ID</th> 
                           <th>Date</th> 
                          <th>Note</th>
                       
                          <th>Action</th>
                        
                        </tr>
                      </thead>


                      <tbody>
                      <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td><?php echo $note->id; ?></td>
                           <td><?php echo $note->created_at; ?></td> 
                          <td><?php echo $note->note; ?></td>
                        
                          <form action="<?php echo e(route('Note',$note->id)); ?>" method="POST">
                             <?php echo csrf_field(); ?>
                            <td class=" last">
                            <a href="<?php echo e(route('Note.edit',$note->id)); ?>"><i class="fa fa-pencil"></i></a>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"  style="border: none;"><i class="fa fa-close"></i></button> 
                          
                            </td>
                            </form>
                          
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                      </tbody>
                    </table>
                    </div>
        </div>



    
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\interview\V-phonix\blog\resources\views/home.blade.php ENDPATH**/ ?>
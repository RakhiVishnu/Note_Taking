<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                   
                    <form action="<?php echo e(url('/Noteupdate/' . $post->id)); ?>" method="POST" enctype="multipart/form-data" class="form-horizontal form-bordered" novalidate>
                                <?php echo csrf_field(); ?>
                <div class="container my-3">
                    <h1>Update your Notes here</h1>
                    <div class="card">

                        <div class="card-body">
                            <h5 class="card-title">
                                Add a Note
                            
                            </h5>
                            <div class="form-group">
                                <textarea class="form-control" 
                                    id="addTxt"  name="addTxt" rows="3"><?php echo e($post->note); ?>

                                </textarea>
                            </div>
                            <button class="btn btn-primary" 
                                id="addBtn" type="submit" style=
                                "background-color:green">
                                Add Note
                            </button>
                        </div>
                        
                    </div>
                    <hr>
                    
                </div>
                </form>
            </div>
        </div>
        
  
    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\interview\V-phonix\blog\resources\views/Note_edit.blade.php ENDPATH**/ ?>